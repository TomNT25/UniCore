using UniCore.Application.Entity;

namespace UniCore.Application.Contract.Repository.Enitity.v1
{
    public interface IDepartmentRepository : IRepository<Department>
    {
    }
}
