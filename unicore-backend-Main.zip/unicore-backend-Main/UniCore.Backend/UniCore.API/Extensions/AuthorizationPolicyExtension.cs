using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;
using UniCore.API.AuthorizationHandler.Permission;

namespace UniCore.API.Extensions
{
    public static class AuthorizationPolicyExtension
    {
        public static void AddAuthorizationPolicyService(this IServiceCollection services)
        {
            services.AddSingleton<IAuthorizationPolicyProvider, DynamicPermissionPolicyProvider>();

            services.AddScoped<IAuthorizationHandler, PermissionAuthorizationHandler>();

            services.AddAuthorization(options =>
            {
                options.AddPolicy("RequireAdmin", policy =>
                    policy.RequireRole("Admin", "Administrator", "SuperAdmin"));

                options.AddPolicy("RequireUser", policy =>
                    policy.RequireAuthenticatedUser());

                options.DefaultPolicy = new AuthorizationPolicyBuilder()
                    .RequireAuthenticatedUser()
                    .Build();
            });
        }

        public static void ConfigureAuthorization(this WebApplication app, IWebHostEnvironment env)
        {
            app.UseAuthorization();
        }
    }
}
